<?php

if (isset($_POST['submit'])) {
    $number = rand(1, 9);
    $carta = getPokemonName($number) . ".png";

    if (isset($_POST['cartasObtenidas']) && !empty($_POST['cartasObtenidas'])) {
        // No es la primera vez que se genera
        $cartasTotales = $_POST['cartasObtenidas']; // Recuperamos las cartas obtenidas previamente
        $cartasTotales .= ",$carta"; // Concatenamos la nueva carta
        $cartasTotalesArray = explode(",", $cartasTotales); // Convertimos en array
    } else {
        // Es la primera vez que se genera
        $cartasTotales = $carta; // Solo hay una carta
        $cartasTotalesArray = [$carta];
    }

    // Mostrar la carta actual con tamaño más grande
    echo "<div style='margin-bottom: 20px;'>";
    echo "<img src='./img/$carta' style='width: 400px; height: auto; border: 2px solid black;'><br>";
    echo "</div>";

    // Generar el formulario con las cartas obtenidas
    obtenerCarta($cartasTotales);

    if (count($cartasTotalesArray) > 1) {
        // Solo se dibujará si hay más de 1 carta generada
        echo "<div style='display: flex; gap: 10px; flex-wrap: wrap;'>";
        foreach ($cartasTotalesArray as $value) {
            echo "<img src='./img/$value' style='width: 100px; height: auto; border: 1px solid gray;'>";
        }
        echo "</div>";
    }
} else {
    obtenerCarta(null);
}

// Función para generar el formulario
function obtenerCarta($cartasObtenidas)
{
    echo "<form method='POST'>";
    if ($cartasObtenidas != null) {
        echo "<input type='hidden' name='cartasObtenidas' value='$cartasObtenidas'>";
    }
    echo "<input type='submit' name='submit' value='Obtener Carta' style='margin-top: 20px;'><br>";
    echo "</form>";
}

// Función para obtener el nombre del Pokémon
function getPokemonName($number)
{
    switch ($number) {
        case 1:
            $name = "Bulbasaur";
            break;
        case 2:
            $name = "Ivysaur";
            break;
        case 3:
            $name = "Venusaur";
            break;
        case 4:
            $name = "Charmander";
            break;
        case 5:
            $name = "Charmeleon";
            break;
        case 6:
            $name = "Charizard";
            break;
        case 7:
            $name = "Squirtle";
            break;
        case 8:
            $name = "Wartortle";
            break;
        case 9:
            $name = "Blastoise";
            break;
    }
    return $name;
}
?>
